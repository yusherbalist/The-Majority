package com.example.darling.frags.oneday.days;

import android.app.DatePickerDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.darling.R;
import com.example.darling.dbHelper.UserDBHelper;
import com.example.darling.enity.Item;
import com.example.darling.util.ToastUtil;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link thirdDayFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class thirdDayFragment extends Fragment implements View.OnClickListener, CompoundButton.OnCheckedChangeListener, DatePickerDialog.OnDateSetListener{

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private EditText et_item;
    private ImageButton imageButton;
    private ImageButton deleteItem;
    private ImageButton completeItem;
    private Item item;
    private UserDBHelper mHelper;
    private CheckBox isdone;
    private int isdone_int=0;
    private boolean a;
    private boolean item_a;
    private LinearLayout linearLayout;

    //public Calendar calendar=Calendar.getInstance();
    public int c_year;
    public int c_month;
    public int c_date;
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    public String item_date;


    private String change_date;


    private int date_id;
    private String date_line;
    private int date_isdone;
    public thirdDayFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment thirdDayFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static thirdDayFragment newInstance(String param1, String param2) {
        thirdDayFragment fragment = new thirdDayFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mHelper=UserDBHelper.getInstance(getActivity());
        mHelper.openReadLink();
        mHelper.openWriteLink();
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_third_day, container, false);
    }
    @Override
    public void onStart() {
        super.onStart();
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, +2);
        calendar.add(Calendar.MONTH,-1);
        date = calendar.getTime();
        String dateline=formatter.format(date);
        String[] spilts=dateline.split("-");
        c_year= Integer.parseInt(spilts[0]);
        c_month= Integer.parseInt(spilts[1]);
        c_date= Integer.parseInt(spilts[2]);

        item_date=String.valueOf(c_year)+"-"+String.valueOf(c_month)+"-"+String.valueOf(c_date);

        deleteItem=getView().findViewById(R.id.deleteItem);
        et_item = getView().findViewById(R.id.haha);
        imageButton = getView().findViewById(R.id.imageButton);
        isdone=getView().findViewById(R.id.isdone);
        completeItem=getView().findViewById(R.id.completeItem);
        linearLayout=getView().findViewById(R.id.linear);
        isdone.setOnCheckedChangeListener(this);
        imageButton.setOnClickListener(this);
        deleteItem.setOnClickListener(this);
        completeItem.setOnClickListener(this);

        showItems();


    }

    @Override
    public void onClick(View vv) {
        String itemline=et_item.getText().toString();
        String date="1";
        switch (vv.getId()){
            case R.id.imageButton:
                item = new Item(item_date,itemline+"avavaava",0);

                if (mHelper.item_insert(item)>0){
                    ToastUtil.show(getActivity(),"添加成功~");
                }
                item=mHelper.queryAddItemsInfo(itemline+"avavaava");
                item.itemline=itemline;
                if(mHelper.item_update_byID(item)>0){

                }


                int scerrnWidth=getResources().getDisplayMetrics().widthPixels;
                LinearLayout.LayoutParams layoutParams=new LinearLayout.LayoutParams(scerrnWidth,LinearLayout.LayoutParams.WRAP_CONTENT);

                View view=LayoutInflater.from(getActivity()).inflate(R.layout.items_example,null);
                TextView item_millcode=view.findViewById(R.id.item_millcode);

                EditText item_itemline=view.findViewById(R.id.item_itemline);
                ImageButton item_complete=view.findViewById(R.id.item_completeItem);
                ImageButton item_delete=view.findViewById(R.id.item_deleteItem);
                ImageButton item_date=view.findViewById(R.id.item_dateItem);
                CheckBox item_isdone=view.findViewById(R.id.item_isdone);



//-----------------------------------------------------------------------------------------------------------------------------------------------------
                item_delete.setOnClickListener(v -> {
                    if (mHelper.item_delete_byID(item.item_id)>0){
                        ToastUtil.show(getActivity(),"删除成功");

                        item_itemline.setLayoutParams(new LinearLayout.LayoutParams(0,0));
                        item_complete.setLayoutParams(new LinearLayout.LayoutParams(0,0));
                        item_delete.setLayoutParams(new LinearLayout.LayoutParams(0,0));
                        item_date.setLayoutParams(new LinearLayout.LayoutParams(0,0));
                        item_isdone.setLayoutParams(new LinearLayout.LayoutParams(0,0));

                    }
                });

                item_complete.setOnClickListener(v -> {
                    item_a=item_isdone.isChecked();
                    if (a==true){
                        isdone_int=1;
                    }else {
                        isdone_int=0;
                    }
                    String line=item_itemline.getText().toString();
                    item=new Item(item.item_id, item.date, line,isdone_int);
                    if(mHelper.item_update_byID(item)>0){
                        ToastUtil.show(getActivity(),"修改成功");
                    }

                });
                item_date.setOnClickListener(v -> {
                    DatePickerDialog dialog=new DatePickerDialog(getActivity(),this,c_year,c_month,c_date);
                    dialog.show();
                    date_id= item.item_id;
                    date_line= item.itemline;
                    date_isdone= item.isdone;

                });

                item_isdone.setOnCheckedChangeListener(this);
//-----------------------------------------------------------------------------------------------------------------------------------------------------
                if (item.isdone==1){
                    item_isdone.setChecked(true);
                }
                item_itemline.setText(item.itemline);

                item_isdone.setId(item.item_id);


                linearLayout.addView(view,layoutParams);



                break;

            case R.id.deleteItem:
                if (mHelper.item_delete(itemline,date)>0){
                    ToastUtil.show(getActivity(),"删除成功~");
                }
                break;


        }
    }

    private void showItems(){
        int scerrnWidth=getResources().getDisplayMetrics().widthPixels;
        LinearLayout.LayoutParams layoutParams=new LinearLayout.LayoutParams(scerrnWidth,LinearLayout.LayoutParams.WRAP_CONTENT);

        List<Item> list = mHelper.queryTodayItemsInfo(item_date);
        for (Item item1 : list) {
            View view=LayoutInflater.from(getActivity()).inflate(R.layout.items_example,null);
            TextView item_millcode=view.findViewById(R.id.item_millcode);
            //EditText item_itemline=view.findViewById(R.id.item_itemline);
            EditText item_itemline=view.findViewById(R.id.item_itemline);
            ImageButton item_complete=view.findViewById(R.id.item_completeItem);
            ImageButton item_delete=view.findViewById(R.id.item_deleteItem);
            ImageButton item_date=view.findViewById(R.id.item_dateItem);
            CheckBox item_isdone=view.findViewById(R.id.item_isdone);

//-----------------------------------------------------------------------------------------------------------------------------------------------------
            item_delete.setOnClickListener(v -> {
                if (mHelper.item_delete_byID(item1.item_id)>0){
                    ToastUtil.show(getActivity(),"删除成功");

                    item_itemline.setLayoutParams(new LinearLayout.LayoutParams(0,0));
                    item_complete.setLayoutParams(new LinearLayout.LayoutParams(0,0));
                    item_delete.setLayoutParams(new LinearLayout.LayoutParams(0,0));
                    item_date.setLayoutParams(new LinearLayout.LayoutParams(0,0));
                    item_isdone.setLayoutParams(new LinearLayout.LayoutParams(0,0));

                }
            });
            item_complete.setOnClickListener(v -> {
                item_a=item_isdone.isChecked();
                if (a==true){
                    isdone_int=1;
                }else {
                    isdone_int=0;
                }
                String line=item_itemline.getText().toString();
                item=new Item(item1.item_id, item1.date, line,isdone_int);
                if(mHelper.item_update_byID(item)>0){
                    ToastUtil.show(getActivity(),"修改成功");
                }

            });
            item_date.setOnClickListener(v -> {
                DatePickerDialog dialog=new DatePickerDialog(getActivity(),this,c_year,c_month,c_date);
                dialog.show();
                date_id= item1.item_id;
                date_line= item1.itemline;
                date_isdone= item1.isdone;

            });

            item_isdone.setOnCheckedChangeListener(this);
//-----------------------------------------------------------------------------------------------------------------------------------------------------
            if (item1.isdone==1){
                item_isdone.setChecked(true);
            }
            item_itemline.setText(item1.itemline);

            item_isdone.setId(item1.item_id);


            linearLayout.addView(view,layoutParams);

        }

    }

    @Override
    public void onStop() {
        super.onStop();
        mHelper.closeLink();
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        //       if(buttonView.getText().toString()==""){return;}

        String itemline=et_item.getText().toString();
        String date="1";
        a=isChecked;

        if (a==true){
            isdone_int=1;

        }else {
            isdone_int=0;
        }

        item=new Item(buttonView.getId(),item_date,itemline,isdone_int);
//        item=new Item(Integer.parseInt("34".toString()),item_date,itemline,isdone_int);
//        if(buttonView.getText().toString()!=""){item=new Item(Integer.parseInt(buttonView.getText().toString()),item_date,itemline,isdone_int);}
        Log.e("sb",buttonView.getText().toString());
        if(mHelper.item_update_byID_noline_nodate(item)>0){
            if(isdone_int==1){ToastUtil.show(getActivity(),"完成啦！");}

        }
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        change_date=String.valueOf(year)+"-"+String.valueOf(month)+"-"+String.valueOf(dayOfMonth);
        item=new Item(date_id, change_date, date_line, date_isdone);
        if(mHelper.item_update_byID(item)>0){
            ToastUtil.show(getActivity(),"修改成功");
        }
    }
    @Override
    public void onResume() {
        super.onResume();
    }
}
