package com.example.darling.frags.oneday;

import androidx.lifecycle.ViewModel;

public class OnedayViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}