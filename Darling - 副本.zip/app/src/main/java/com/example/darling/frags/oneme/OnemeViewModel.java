package com.example.darling.frags.oneme;

import androidx.lifecycle.ViewModel;

public class OnemeViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}