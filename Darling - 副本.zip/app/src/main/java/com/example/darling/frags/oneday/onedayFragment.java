package com.example.darling.frags.oneday;

import static androidx.viewpager.widget.PagerAdapter.POSITION_NONE;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.darling.R;
import com.example.darling.frags.oneday.days.firstDayFragment;
import com.example.darling.frags.oneday.days.otherDayFragment;
import com.example.darling.frags.oneday.days.secondDayFragment;
import com.example.darling.frags.oneday.days.thirdDayFragment;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class onedayFragment extends Fragment {

    private OnedayViewModel mViewModel;

    ViewPager2 viewPager;
    TabLayout tableLayout;
    //public int getItemPosition(Object object){ return POSITION_NONE;}
    public static onedayFragment newInstance() {
        return new onedayFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_oneday, container, false);
    }
    public void onStart() {

        super.onStart();
        viewPager = getView().findViewById(R.id.viewPager2);
        tableLayout = getView().findViewById(R.id.tabLayout);

        viewPager.setAdapter(new FragmentStateAdapter(this) {
            @NonNull
            @Override
            public Fragment createFragment(int position) {
                switch (position) {
                    case 0:
                        return new firstDayFragment();
                    case 1:
                        return new secondDayFragment();
                    case 2:
                        return new thirdDayFragment();
                    default:
                        return new otherDayFragment();
                }
            }

            @Override
            public int getItemCount() {
                return 4;
            }
        });

        new TabLayoutMediator(tableLayout, viewPager, (tab, position) -> {
            switch (position) {
                case 0:
                    tab.setText("Being");
                    break;
                case 1:
                    tab.setText("After");
                    break;
                case 2:
                    tab.setText("Later");
                    break;
                default:
                    tab.setText("Other");
            }
        }).attach();
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(OnedayViewModel.class);
        // TODO: Use the ViewModel
    }

}