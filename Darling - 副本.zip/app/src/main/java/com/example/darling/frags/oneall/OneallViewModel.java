package com.example.darling.frags.oneall;

import androidx.lifecycle.ViewModel;

public class OneallViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}