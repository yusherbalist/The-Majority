package com.example.darling.enity;

public class Me {
    public int me_id;
    public String me_fruit ;//水果1x1
    public String me_run;//跑步3x1
    public String me_fly;//自律3x3
    public String me_exercise;//健身3x2
    public String me_english;//英语4x2
    public String me_shower;//洗澡2x1
    public String me_laundry;//洗衣2x2
    public String me_clean;//打扫2x3
    public String me_nail;//指甲2x4
    public String me_stocks;//基金4x1
    public String me_moodle;//作业4x3
    public String me_drink;//喝水1x2
    //---------------------------------
    public String me_face;
    public String me_haircut;
    public String me_ill;//吃药1x3
    public String me_table;
    public String isdone;
    public String me_shaver;
    public String me_tooth;
    public String me_teeth;
    public String me_acid;
    public String me_sock;

    public Me() {
    }

    public Me(int me_id,String me_fruit, String me_run, String me_fly, String me_exercise, String me_english,
              String me_shower, String me_laundry, String me_table, String me_clean, String me_nail,
              String me_stocks, String me_moodle, String me_drink, String me_haircut, String me_ill,
              String me_face, String me_shaver, String me_tooth, String me_teeth,String me_acid,String me_sock,
              String isdone
    ) {
        this.me_id=me_id;
        this.me_fruit = me_fruit;
        this.me_run = me_run;
        this.me_fly = me_fly;
        this.me_exercise = me_exercise;
        this.me_english = me_english;
        this.me_shower = me_shower;
        this.me_laundry = me_laundry;
        this.me_table = me_table;
        this.me_clean = me_clean;
        this.me_nail = me_nail;
        this.me_stocks = me_stocks;
        this.me_moodle = me_moodle;
        this.me_drink = me_drink;
        this.me_haircut = me_haircut;
        this.me_ill = me_ill;
        //------------------------------
        this.me_face=me_face;
        this.me_shaver=me_shaver;
        this.me_tooth=me_tooth;
        this.me_teeth=me_teeth;
        this.me_acid=me_acid;
        this.me_sock=me_sock;
        //------------------------------
        this.isdone = isdone;


    }
}
