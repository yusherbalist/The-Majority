package com.example.darling.frags.oneme;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.example.darling.R;
import com.example.darling.dbHelper.UserDBHelper;
import com.example.darling.enity.Me;
import com.example.darling.util.ToastUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class onemeFragment extends Fragment implements View.OnClickListener {

    private OnemeViewModel mViewModel;
    private UserDBHelper mHelper;
    private Me me;
    public Calendar calendar=Calendar.getInstance();
    public int c_year;
    public int c_month;
    public int c_date;
    public String me_date;
    public DateFormat dateFormat;

    ImageButton apple_btn;
    ImageButton fruit_btn;
    ImageButton run_btn;
    ImageButton fly_btn;
    ImageButton exercise_btn;
    ImageButton english_btn;
    ImageButton shower_btn;
    ImageButton laundry_btn;
    ImageButton clean_btn;
    ImageButton nail_btn;
    ImageButton stocks_btn;
    ImageButton moodle_btn;
    ImageButton drink_btn;
    ImageButton ill_btn;
    ImageButton face_btn;
    ImageButton shaver_btn;
    ImageButton tooth_btn;
    ImageButton teeth_btn;
    ImageButton acid_btn;
    ImageButton sock_btn;

    public static onemeFragment newInstance() {
        return new onemeFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_oneme, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(OnemeViewModel.class);
        // TODO: Use the ViewModel
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mHelper = UserDBHelper.getInstance(getActivity());
        mHelper.openReadLink();
        mHelper.openWriteLink();
        dateFormat=new SimpleDateFormat("yyyy-MM-dd");

    }

    @Override
    public void onStart() {
        super.onStart();
        c_year=calendar.get(Calendar.YEAR);
        c_month=calendar.get(Calendar.MONTH)+1;
        c_date=calendar.get(Calendar.DATE);
        me_date=String.valueOf(c_year)+"-"+String.valueOf(c_month)+"-"+String.valueOf(c_date);

        apple_btn = getView().findViewById(R.id.apple_btn);
        apple_btn.setOnClickListener(this);

        run_btn = getView().findViewById(R.id.run_btn);
        run_btn.setOnClickListener(this);

        fly_btn = getView().findViewById(R.id.fly_btn);
        fly_btn.setOnClickListener(this);

        exercise_btn = getView().findViewById(R.id.exercise_btn);
        exercise_btn.setOnClickListener(this);

        english_btn = getView().findViewById(R.id.english_btn);
        english_btn.setOnClickListener(this);

        shower_btn = getView().findViewById(R.id.shower_btn);
        shower_btn.setOnClickListener(this);

        laundry_btn = getView().findViewById(R.id.laundry_btn);
        laundry_btn.setOnClickListener(this);

        clean_btn = getView().findViewById(R.id.clean_btn);
        clean_btn.setOnClickListener(this);

        clean_btn = getView().findViewById(R.id.clean_btn);
        clean_btn.setOnClickListener(this);

        nail_btn = getView().findViewById(R.id.nail_btn);
        nail_btn.setOnClickListener(this);

        stocks_btn = getView().findViewById(R.id.stocks_btn);
        stocks_btn.setOnClickListener(this);

        moodle_btn = getView().findViewById(R.id.moodle_btn);
        moodle_btn.setOnClickListener(this);

        drink_btn = getView().findViewById(R.id.drink_btn);
        drink_btn.setOnClickListener(this);

        ill_btn = getView().findViewById(R.id.ill_btn);
        ill_btn.setOnClickListener(this);

        face_btn = getView().findViewById(R.id.face_btn);
        face_btn.setOnClickListener(this);

        shaver_btn = getView().findViewById(R.id.shaver_btn);
        shaver_btn.setOnClickListener(this);

        tooth_btn = getView().findViewById(R.id.tooth_btn);
        tooth_btn.setOnClickListener(this);

        teeth_btn = getView().findViewById(R.id.teeth_btn);
        teeth_btn.setOnClickListener(this);

        acid_btn = getView().findViewById(R.id.acid_btn);
        acid_btn.setOnClickListener(this);

        sock_btn = getView().findViewById(R.id.sock_btn);
        sock_btn.setOnClickListener(this);


        List<Me> list = mHelper.queryAllMeInfo();

        if(list.isEmpty()){
            me = new Me(1,"1", "1", "1", "1", "1", "1", "1",
                "1", "1", "1", "1", "1", "1", "1", "1",
                    "1","1","1","1","1","1","1");
            if (mHelper.me_insert(me) > 0) {
                ToastUtil.show(getActivity(), "添加成功");
            }
        }

            me= list.get(0);

        if (dateminus(me.me_fruit,me_date)<1){apple_btn.setImageDrawable(getResources().getDrawable(R.drawable.apple_color_me));}
        if (dateminus(me.me_drink,me_date)<1){drink_btn.setImageDrawable(getResources().getDrawable(R.drawable.drink_color_me));}
        if (dateminus(me.me_ill,me_date)<1){ill_btn.setImageDrawable(getResources().getDrawable(R.drawable.ill_color_me));}

        if (dateminus(me.me_shower,me_date)<1){shower_btn.setImageDrawable(getResources().getDrawable(R.drawable.shower_color_me));}
        if (dateminus(me.me_laundry,me_date)<2){laundry_btn.setImageDrawable(getResources().getDrawable(R.drawable.laundry_color_me));}
        if (dateminus(me.me_clean,me_date)<3){clean_btn.setImageDrawable(getResources().getDrawable(R.drawable.clean_color_me));}
        if (dateminus(me.me_nail,me_date)<7){nail_btn.setImageDrawable(getResources().getDrawable(R.drawable.nail_color_me));}

        if (dateminus(me.me_run,me_date)<2){run_btn.setImageDrawable(getResources().getDrawable(R.drawable.run_color_me));}
        if (dateminus(me.me_exercise,me_date)<2){exercise_btn.setImageDrawable(getResources().getDrawable(R.drawable.exercise_color_me));}
        if (dateminus(me.me_fly,me_date)>5){fly_btn.setImageDrawable(getResources().getDrawable(R.drawable.fly_color_me));}

        if (dateminus(me.me_stocks,me_date)<1){stocks_btn.setImageDrawable(getResources().getDrawable(R.drawable.stocks_color_me));}
        if (dateminus(me.me_english,me_date)<1){english_btn.setImageDrawable(getResources().getDrawable(R.drawable.english_color_me));}
        if (dateminus(me.me_moodle,me_date)<1){moodle_btn.setImageDrawable(getResources().getDrawable(R.drawable.moodle_color_me));}

        if (dateminus(me.me_face,me_date)<5){face_btn.setImageDrawable(getResources().getDrawable(R.drawable.face_color_me));}
        if (dateminus(me.me_shaver,me_date)<5){shaver_btn.setImageDrawable(getResources().getDrawable(R.drawable.shaver_color_me));}
        if (dateminus(me.me_acid,me_date)<5){acid_btn.setImageDrawable(getResources().getDrawable(R.drawable.acid_color_me));}
        if (dateminus(me.me_sock,me_date)<5){sock_btn.setImageDrawable(getResources().getDrawable(R.drawable.sock_color_me));}
        if (dateminus(me.me_tooth,me_date)<5){tooth_btn.setImageDrawable(getResources().getDrawable(R.drawable.tooth_color_me));}
        if (dateminus(me.me_teeth,me_date)<5){teeth_btn.setImageDrawable(getResources().getDrawable(R.drawable.tooth_color_me));}




    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.apple_btn:
                me.me_fruit=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "要多吃水果捏~");
                }
                apple_btn.setImageDrawable(getResources().getDrawable(R.drawable.apple_color_me));
                break;
            case R.id.run_btn:
                me.me_run=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "一定要坚持哦~");
                }
                run_btn.setImageDrawable(getResources().getDrawable(R.drawable.run_color_me));
                break;
            case R.id.fly_btn:
                me.me_fly=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "不好不好:(");
                }
                fly_btn.setImageDrawable(getResources().getDrawable(R.drawable.fly_me));
                break;
            case R.id.exercise_btn:
                me.me_exercise=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "练完要拉伸哦~");
                }
                exercise_btn.setImageDrawable(getResources().getDrawable(R.drawable.exercise_color_me));
                break;
            case R.id.english_btn:
                me.me_english=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "好棒！继续加油");
                }
                english_btn.setImageDrawable(getResources().getDrawable(R.drawable.english_color_me));
                break;
            case R.id.shower_btn:
                me.me_shower=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "我爱洗澡皮肤好好~");
                }
                shower_btn.setImageDrawable(getResources().getDrawable(R.drawable.shower_color_me));
                break;
            case R.id.laundry_btn:
                me.me_laundry=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "衣服也要香香的捏");
                }
                laundry_btn.setImageDrawable(getResources().getDrawable(R.drawable.laundry_color_me));
                break;
            case R.id.clean_btn:
                me.me_clean=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "下次不要再搞乱咯");
                }
                clean_btn.setImageDrawable(getResources().getDrawable(R.drawable.clean_color_me));
                break;
            case R.id.nail_btn:
                me.me_nail=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "这很重要！");
                }
                nail_btn.setImageDrawable(getResources().getDrawable(R.drawable.nail_color_me));
                break;
            case R.id.stocks_btn:
                me.me_stocks=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "今晚吃点好的！");
                }
                stocks_btn.setImageDrawable(getResources().getDrawable(R.drawable.stocks_color_me));
                break;
            case R.id.moodle_btn:
                me.me_moodle=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "别忘交作业哦~");
                }
                moodle_btn.setImageDrawable(getResources().getDrawable(R.drawable.moodle_color_me));
                break;
            case R.id.drink_btn:
                me.me_drink=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), String.valueOf(dateminus(me.me_drink,me_date)));
                }
                drink_btn.setImageDrawable(getResources().getDrawable(R.drawable.drink_color_me));
                break;
            case R.id.ill_btn:
                me.me_ill=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), "ill");
                }
                ill_btn.setImageDrawable(getResources().getDrawable(R.drawable.ill_color_me));
                break;
            case R.id.face_btn:
                me.me_face=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), String.valueOf(dateminus(me.me_face,me_date)));
                }
                face_btn.setImageDrawable(getResources().getDrawable(R.drawable.face_color_me));
                break;
            case R.id.shaver_btn:
                me.me_shaver=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), String.valueOf(dateminus(me.me_face,me_date)));
                }
                shaver_btn.setImageDrawable(getResources().getDrawable(R.drawable.shaver_color_me));
                break;
            case R.id.tooth_btn:
                me.me_tooth=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), String.valueOf(dateminus(me.me_face,me_date)));
                }
                tooth_btn.setImageDrawable(getResources().getDrawable(R.drawable.tooth_color_me));
                break;

            case R.id.teeth_btn:
                me.me_teeth=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), String.valueOf(dateminus(me.me_face,me_date)));
                }
                teeth_btn.setImageDrawable(getResources().getDrawable(R.drawable.tooth_color_me));
                break;
            case R.id.acid_btn:
                me.me_acid=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), String.valueOf(dateminus(me.me_face,me_date)));
                }
                acid_btn.setImageDrawable(getResources().getDrawable(R.drawable.acid_color_me));
                break;
            case R.id.sock_btn:
                me.me_sock=me_date;
                if (mHelper.me_update_byID(me) > 0) {
                    ToastUtil.show(getActivity(), String.valueOf(dateminus(me.me_face,me_date)));
                }
                sock_btn.setImageDrawable(getResources().getDrawable(R.drawable.sock_color_me));
                break;
        }
    }
    @Override
    public void onStop() {
        super.onStop();

    }
    public long dateminus(String startDate, String endDate){
        try {
            Date datestart=dateFormat.parse(startDate);
            Date datenot = dateFormat.parse(endDate);
            Long starttime=datestart.getTime();
            long nottime=datenot.getTime();
            //Log.e("sb", String.valueOf(((nottime-starttime)/24/60/60/1000)));
            return ((nottime-starttime)/24/60/60/1000);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 100;
    }
}