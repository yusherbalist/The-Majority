package com.example.darling.enity;

public class Item {
    public int item_id;
    public String date ;
    public String itemline;
    public int isdone;

    public Item(){

    }

    public Item(String date, String item, int isdone) {

        this.date = date;
        this.itemline = item;
        this.isdone = isdone;
    }

    public Item(int item_id, String date, String itemline, int isdone) {
        this.item_id = item_id;
        this.date = date;
        this.itemline = itemline;
        this.isdone = isdone;
    }

    @Override
    public String toString() {
        return "Item{" +
                "item_id=" + item_id +
                ", date='" + date + '\'' +
                ", item='" + itemline + '\'' +
                ", isdone=" + isdone +
                '}';
    }
}
