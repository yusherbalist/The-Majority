package com.example.darling.dbHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.darling.enity.Item;
import com.example.darling.enity.Me;
import com.example.darling.frags.oneday.days.firstDayFragment;

import java.util.ArrayList;
import java.util.List;

public class UserDBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME="user.db";
    public static final int DB_VERSION=1;
    public static final String ITEM_TABLE_NAME="item_info";
    public static final String ME_TABLE_NAME="me_info";
    public static final String ALL_TABLE_NAME="me_info0";
    private static UserDBHelper mHelper=null;
    private SQLiteDatabase mRDB = null;
    private SQLiteDatabase mWDB = null;


    public static UserDBHelper getInstance(Context context){
        if (mHelper==null){
            mHelper=new UserDBHelper(context);
        }
        return mHelper;
    }

    public SQLiteDatabase openReadLink(){
        if (mRDB==null || !mRDB.isOpen()){
            mRDB=mHelper.getReadableDatabase();
        }
        return mRDB;
    }

    public SQLiteDatabase openWriteLink(){
        if (mWDB==null || !mWDB.isOpen()){
            mWDB=mHelper.getWritableDatabase();
        }
        return mRDB;
    }

    public void closeLink(){
        if(mRDB!=null &&mRDB.isOpen()){
            mRDB.close();;
            mRDB=null;
        }
        if(mWDB!=null &&mWDB.isOpen()){
            mWDB.close();;
            mWDB=null;
        }
    }

    private UserDBHelper(Context context) {
        super(context,DB_NAME,null,DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql="CREATE TABLE IF NOT EXISTS "+ITEM_TABLE_NAME+" (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                " date VARCHAR NOT NULL," +
                " item VARCHAR NOT NULL," +
                " isdone INTEGER NOT NULL);";
        db.execSQL(sql);
        sql="CREATE TABLE IF NOT EXISTS "+ME_TABLE_NAME+" (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                " me_fruit VARCHAR NOT NULL," +
                " me_fly VARCHAR NOT NULL," +
                " me_exercise VARCHAR NOT NULL," +
                " me_english VARCHAR NOT NULL," +
                " me_run VARCHAR NOT NULL," +
                " me_shower VARCHAR NOT NULL," +
                " me_laundry VARCHAR NOT NULL," +
                " me_table VARCHAR NOT NULL," +
                " me_clean VARCHAR NOT NULL," +
                " me_nail VARCHAR NOT NULL," +
                " me_stocks VARCHAR NOT NULL," +
                " me_moodle VARCHAR NOT NULL," +
                " me_drink VARCHAR NOT NULL," +
                " me_haircut VARCHAR NOT NULL," +
                //------------------------------------------
                " me_ill VARCHAR NOT NULL," +
                " me_face VARCHAR NOT NULL," +
                " me_shaver VARCHAR NOT NULL," +
                " me_tooth VARCHAR NOT NULL," +
                " me_teeth VARCHAR NOT NULL," +
                " me_acid VARCHAR NOT NULL," +

                //------------------------------------------
                " me_sock VARCHAR NOT NULL);";
        db.execSQL(sql);
        //db.execSQL("delete from me_info");
        //db.execSQL("drop table me_info");


    }

    public long me_insert(Me me){
        ContentValues values_me=new ContentValues();
        values_me.put("me_fruit",me.me_fruit);
        values_me.put("me_fly",me.me_fly);
        values_me.put("me_exercise",me.me_exercise);
        values_me.put("me_english",me.me_english);
        values_me.put("me_run",me.me_run);
        values_me.put("me_shower",me.me_shower);
        values_me.put("me_laundry",me.me_laundry);
        values_me.put("me_table",me.me_table);
        values_me.put("me_clean",me.me_clean);
        values_me.put("me_nail",me.me_nail);
        values_me.put("me_stocks",me.me_stocks);
        values_me.put("me_moodle",me.me_moodle);
        values_me.put("me_drink",me.me_drink);
        values_me.put("me_haircut",me.me_haircut);
        values_me.put("me_ill",me.me_ill);
        values_me.put("me_face",me.me_face);
        values_me.put("me_shaver",me.me_shaver);
        values_me.put("me_tooth",me.me_tooth);
        values_me.put("me_teeth",me.me_teeth);
        values_me.put("me_acid",me.me_acid);
        values_me.put("me_sock",me.me_sock);
        return mWDB.insert(ME_TABLE_NAME,null,values_me);
    }
    public long item_insert(Item item){
        ContentValues values=new ContentValues();
        values.put("item",item.itemline);
        values.put("date",item.date);
        values.put("isdone",item.isdone);
        return mWDB.insert(ITEM_TABLE_NAME,null,values);

    }
    public long item_delete(String itemline ,String date){
        return mWDB.delete(ITEM_TABLE_NAME,"item=? and date=?",new String[]{itemline,date});

    }
    public long item_delete_byID(int _id){
        return mWDB.delete(ITEM_TABLE_NAME,"_id=?",new String[]{String.valueOf(_id)});

    }
    public long item_update(Item item){
        ContentValues values=new ContentValues();
        values.put("item",item.itemline);
        values.put("date",item.date);
        values.put("isdone",item.isdone);
        return mWDB.update(ITEM_TABLE_NAME,values,"item=? and date=?",new String[]{item.itemline,item.date});
    }
    public long item_update_byID(Item item){
        ContentValues values=new ContentValues();
        values.put("_id",item.item_id);
        values.put("item",item.itemline);
        values.put("date",item.date);
        values.put("isdone",item.isdone);
        return mWDB.update(ITEM_TABLE_NAME,values,"_id=?",new String[]{String.valueOf(item.item_id)});
    }
    public long item_update_byID_noline_nodate(Item item){
        ContentValues values=new ContentValues();
        values.put("_id",item.item_id);


        values.put("isdone",item.isdone);
        return mWDB.update(ITEM_TABLE_NAME,values,"_id=?",new String[]{String.valueOf(item.item_id)});
    }

    //public long me_
    public long me_update_byID(Me me){
        ContentValues values_me=new ContentValues();
        values_me.put("_id",me.me_id);
        values_me.put("me_fruit",me.me_fruit);
        values_me.put("me_fly",me.me_fly);
        values_me.put("me_exercise",me.me_exercise);
        values_me.put("me_english",me.me_english);
        values_me.put("me_run",me.me_run);
        values_me.put("me_shower",me.me_shower);
        values_me.put("me_laundry",me.me_laundry);
        values_me.put("me_table",me.me_table);
        values_me.put("me_clean",me.me_clean);
        values_me.put("me_nail",me.me_nail);
        values_me.put("me_stocks",me.me_stocks);
        values_me.put("me_moodle",me.me_moodle);
        values_me.put("me_drink",me.me_drink);
        values_me.put("me_haircut",me.me_haircut);
        values_me.put("me_ill",me.me_ill);
        values_me.put("me_face",me.me_face);
        values_me.put("me_shaver",me.me_shaver);
        values_me.put("me_tooth",me.me_tooth);
        values_me.put("me_teeth",me.me_teeth);
        values_me.put("me_acid",me.me_acid);
        values_me.put("me_sock",me.me_sock);
        return mWDB.update(ME_TABLE_NAME,values_me,"_id=?",new String[]{String.valueOf(me.me_id)});
    }

    public List<Item> queryAllItemsInfo(){
        String sql = "SELECT * FROM "+ITEM_TABLE_NAME;
        List<Item> list =new ArrayList<>();
        Cursor cursor =mRDB.rawQuery(sql,null);
        while (cursor.moveToNext()){
            Item aitem =new Item();
            aitem.item_id=cursor.getInt(0);
            aitem.date=cursor.getString(1);
            aitem.itemline=cursor.getString(2);
            aitem.isdone=cursor.getInt(3);
            list.add(aitem);
        }
        cursor.close();
        return list;
    }
    public List<Item> queryTodayItemsInfo(String today_date){
        String sql = "SELECT * FROM "+ITEM_TABLE_NAME+" WHERE date=? ORDER BY isdone ASC";
        List<Item> list =new ArrayList<>();
        Cursor cursor =mRDB.rawQuery(sql,new String[]{today_date});
        while (cursor.moveToNext()){
            Item aitem =new Item();
            aitem.item_id=cursor.getInt(0);
            aitem.date=cursor.getString(1);
            aitem.itemline=cursor.getString(2);
            aitem.isdone=cursor.getInt(3);
            list.add(aitem);
        }
        cursor.close();
        return list;
    }
    public Item queryAddItemsInfo(String line){
        String sql = "SELECT * FROM "+ITEM_TABLE_NAME+" WHERE item=?";
        Item aitem =new Item();
        Cursor cursor =mRDB.rawQuery(sql,new String[]{line});
        while (cursor.moveToNext()){

            aitem.item_id=cursor.getInt(0);
            aitem.date=cursor.getString(1);
            aitem.itemline=cursor.getString(2);
            aitem.isdone=cursor.getInt(3);

        }
        cursor.close();
        return aitem;
    }

    public List<Me> queryAllMeInfo(){
        String sql = "SELECT * FROM "+ME_TABLE_NAME;
        List<Me> list =new ArrayList<>();
        Cursor cursor =mRDB.rawQuery(sql,null);
        while (cursor.moveToNext()){
            Me ame=new Me();
            ame.me_id=cursor.getInt(0);
            ame.me_fruit=cursor.getString(1);
            ame.me_fly=cursor.getString(2);
            ame.me_exercise=cursor.getString(3);
            ame.me_english=cursor.getString(4);
            ame.me_run=cursor.getString(5);
            ame.me_shower=cursor.getString(6);
            ame.me_laundry=cursor.getString(7);
            ame.me_table=cursor.getString(8);
            ame.me_clean=cursor.getString(9);
            ame.me_nail=cursor.getString(10);
            ame.me_stocks=cursor.getString(11);
            ame.me_moodle=cursor.getString(12);
            ame.me_drink=cursor.getString(13);
            ame.me_haircut=cursor.getString(14);
            ame.me_ill=cursor.getString(15);
            ame.me_face=cursor.getString(16);
            ame.me_shaver=cursor.getString(17);
            ame.me_tooth=cursor.getString(18);
            ame.me_teeth=cursor.getString(19);
            ame.me_acid=cursor.getString(20);
            ame.me_sock=cursor.getString(21);


            list.add(ame);
        }
        cursor.close();
        return list;
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
